cd tmp/webserver
source env/bin/activate
python3 manage.py runserver
