# YOLOv3 for detection

This is an implemention of YOLOv3 with only the forward part.

If you want to train YOLOv3 on your custom dataset, please search `YOLOv3` on github.

## Quick forward
```bash
cd YOLOv3
python 
```