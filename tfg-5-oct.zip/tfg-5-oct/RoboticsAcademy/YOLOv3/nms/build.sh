cd ext

python build.py build_ext develop

cd ..
