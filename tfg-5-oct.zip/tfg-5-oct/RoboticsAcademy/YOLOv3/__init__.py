import sys
sys.path.append("detector/YOLOv3")


from .detector import YOLOv3
__all__ = ['YOLOv3']



