cd tmp/webserver
source env/bin/activate
cd react_frontend
npm install && npm run dev
