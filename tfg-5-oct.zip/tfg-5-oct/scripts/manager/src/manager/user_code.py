from gui import GUI
from hal import HAL
# Enter sequential code!


image = HAL.getImage();
GUI.showImage(image);
HAL.setW(1);