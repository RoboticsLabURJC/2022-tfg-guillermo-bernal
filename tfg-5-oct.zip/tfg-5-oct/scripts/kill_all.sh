#!/bin/bash

pkill -9 -f gzserver
pkill -9 -f gzclient
pkill -9 -f xterm
pkill -9 -f rviz
pkill -9 -f rosmaster
pkill -9 -f xorg
pkill -9 -f websockify
pkill -9 -f python
