#!/bin/bash

ros_setup="source /.env && source ~/.bashrc && source /home/ws/install/setup.bash"

./entrypoint.sh

eval ${ros_setup} && echo 'environment set'

ros2 launch tello_driver teleop_launch.py > /dev/null 2>&1 &

ros2 service call /tello_action tello_msgs/TelloAction "{cmd: 'land'}"
sleep 2
ros2 service call /tello_action tello_msgs/TelloAction "{cmd: 'emergency'}"